

<?php $__env->startPush('styles'); ?>
<!-- Toastr CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-12">
            <div class="page-title-box d-md-flex justify-content-md-between align-items-center">
                <h4 class="page-title">Manage Features: <?php echo e($plan->name); ?></h4>
                <div class="">
                    <ol class="breadcrumb mb-0">
                        <li class="breadcrumb-item"><a href="#">Creative AI</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('plans.index')); ?>">Plans</a></li>
                        <li class="breadcrumb-item active">Features</li>
                    </ol>
                </div>                            
            </div>
        </div>
    </div>
    <div class="row justify-content-center">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Feature Configuration</h4>
                    <p class="text-muted mb-4">Set feature values for this plan</p>

                    <form action="<?php echo e(route('plans.features.update', $plan)); ?>" method="POST" id="features-form">
                        <?php echo csrf_field(); ?>
                        
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead class="table-light">
                                    <tr>
                                        <th width="40%">Feature</th>
                                        <th width="20%">Type</th>
                                        <th width="40%">Value</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($feature->name); ?></td>
                                        <td>
                                            <span class="badge bg-<?php echo e($feature->type === 'boolean' ? 'primary' : ($feature->type === 'integer' ? 'info' : 'success')); ?>">
                                                <?php echo e(ucfirst($feature->type)); ?>

                                            </span>
                                        </td>
                                        <td>
                                            <?php
                                                $currentValue = $plan->features->where('id', $feature->id)->first()->pivot->value ?? '';
                                            ?>
                                            
                                            <?php if($feature->type === 'boolean'): ?>
                                                <select name="features[<?php echo e($feature->id); ?>]" class="form-select">
                                                    <option value="0" <?php echo e($currentValue == '0' ? 'selected' : ''); ?>>No</option>
                                                    <option value="1" <?php echo e($currentValue == '1' ? 'selected' : ''); ?>>Yes</option>
                                                </select>
                                            <?php elseif($feature->type === 'integer'): ?>
                                                <input type="number" name="features[<?php echo e($feature->id); ?>]" 
                                                       value="<?php echo e($currentValue); ?>" class="form-control">
                                            <?php else: ?>
                                                <input type="text" name="features[<?php echo e($feature->id); ?>]" 
                                                       value="<?php echo e($currentValue); ?>" class="form-control">
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                        <div class="mt-4">
                            <button type="submit" class="btn btn-primary waves-effect waves-light">
                                <i class="ri-save-line align-middle me-1"></i> Save Changes
                            </button>
                            <a href="<?php echo e(route('plans.index')); ?>" class="btn btn-secondary waves-effect ms-2">
                                <i class="ri-close-line align-middle me-1"></i> Cancel
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.getElementById('features-form').addEventListener('submit', function(e) {
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\voice-bot-dashboard\resources\views/admin/plans/features.blade.php ENDPATH**/ ?>