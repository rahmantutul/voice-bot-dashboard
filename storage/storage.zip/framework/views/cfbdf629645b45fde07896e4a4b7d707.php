    <div class="startbar d-print-none">
        <div class="brand d-flex justify-content-center align-items-center">
            <a href="<?php echo e(route('home')); ?>" class="logo text-center">
                <span>
                    <img src="<?php echo e(asset('/')); ?>assets/images/normal.png" alt="logo-small" class="logo-sm mx-auto">
                </span>
                <span>
                    <img src="<?php echo e(asset('/')); ?>assets/images/crtvai.png" height="100" alt="logo-large" class="logo-lg logo-light mx-auto">
                    <img src="<?php echo e(asset('/')); ?>assets/images/crtvai.png" height="100" alt="logo-large" class="logo-lg logo-dark mx-auto">
                </span>
            </a>
        </div>

        <div class="startbar-menu" >
            <div class="startbar-collapse" id="startbarCollapse" data-simplebar>
                <div class="d-flex align-items-start flex-column w-100">
                    <!-- Navigation -->
                    <ul class="navbar-nav mb-auto w-100">
                        <li class="nav-item <?php echo e(Route::is('admin.dashboard') ? 'active' : ''); ?>">
                            <a class="nav-link <?php echo e(Route::is('admin.dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('admin.dashboard')); ?>">
                                <i class="iconoir-report-columns menu-icon"></i>
                                <span>Dashboard</span>
                            </a>
                        </li>
                        <li class="nav-item <?php echo e(Route::is('admins.*') ? 'active' : ''); ?>">
                            <a class="nav-link <?php echo e(Route::is('admins.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.admins.index')); ?>">
                                <i class="fas fa-user menu-icon"></i>
                                <span>Admins</span>
                            </a>
                        </li>
                       <li class="nav-item <?php echo e(Route::is('plans.*') ? 'active' : ''); ?>">
                            <a class="nav-link <?php echo e(Route::is('plans.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.plans.index')); ?>">
                                <i class="fas fa-tags menu-icon"></i>
                                <span>Price Plan</span>
                            </a>
                        </li>
                        <li class="nav-item <?php echo e(Route::is('features.*') ? 'active' : ''); ?>">
                            <a class="nav-link <?php echo e(Route::is('features.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.features.index')); ?>">
                                <i class="fas fa-star menu-icon"></i>
                                <span>Features</span>
                            </a>
                        </li>
                        <li class="nav-item <?php echo e(Route::is('admin.settings.edit') ? 'active' : ''); ?>">
                            <a class="nav-link <?php echo e(Route::is('admin.settings.edit') ? 'active' : ''); ?>" href="<?php echo e(route('admin.settings.edit')); ?>">
                                <i class="fas fa-cogs menu-icon"></i>
                                <span>System Configuration</span>
                            </a>
                        </li>
                    </ul><!--end navbar-nav--->
                    
                </div>
            </div><!--end startbar-collapse-->
        </div>   
    </div><?php /**PATH C:\xampp\htdocs\voice-bot-dashboard\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>